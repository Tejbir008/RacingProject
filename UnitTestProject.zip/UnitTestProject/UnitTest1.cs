﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RacingProject;

namespace UnitTestProject
{
    [TestClass]
    public class UnitTest1
    {
        Guy objBike = new Guy();
        public int Amount = 50;
        public int BikeNumber = 1;
        [TestMethod]
        public void PlaceBetTesting()
        {
           bool Success= objBike.PlaceBet(Amount, BikeNumber);
            if(Success)
            {
                Console.WriteLine("Successfully Placed Bet");
            }
            else
            {
                Console.WriteLine("Error on Place Bet");
            }
        }
    }
}
